import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Embedding, Conv1D, Dense, Input, GlobalMaxPooling1D, Activation, Add
from sklearn.model_selection import KFold
import numpy as np
import dataProgress
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.layers import Layer, Softmax
from tensorflow.keras.metrics import Metric
from tensorflow.keras.optimizers import Adam


# 定义注意力层
class AttentionLayer(Layer):
    def __init__(self):
        super(AttentionLayer, self).__init__()
        # 初始化层时没有任何操作

    def build(self, input_shape):
        # 建立权重W和偏置b，用于后面的线性变换
        # input_shape[-1]是输入特征的维度
        self.W = self.add_weight(name="att_weight", shape=(input_shape[-1], 1),
                                 initializer="normal")  # 权重W初始化为正态分布
        # input_shape[1]是输入序列的时间步（或序列长度）
        self.b = self.add_weight(name="att_bias", shape=(input_shape[1], 1),
                                 initializer="zeros")  # 偏置b初始化为0

    def call(self, inputs):
        # 使用tanh激活函数应用一个线性变换来计算注意力得分（scores）
        # 这里tf.keras.backend.dot是用于矩阵乘法
        e = tf.keras.backend.tanh(tf.keras.backend.dot(inputs, self.W) + self.b)

        # 使用softmax计算每个时间步的权重（注意力得分）
        # 这些权重将用于计算加权求和
        alpha = Softmax(axis=1)(e)  # axis=1表示在时间步上进行softmax

        # 根据注意力得分对输入进行加权求和，以产生加权的上下文向量
        context = inputs * alpha

        # 对于每个样本，通过axis=1求和以得到最终的上下文向量
        return tf.keras.backend.sum(context, axis=1)


# 计算F1指标
class F1Score(Metric):
    def __init__(self, name='f1_score', **kwargs):
        super(F1Score, self).__init__(name=name, **kwargs)
        self.precision_m = tf.keras.metrics.Precision()
        self.recall_m = tf.keras.metrics.Recall()
        self.true_positives = self.add_weight(name='tp', initializer='zeros')
        self.false_positives = self.add_weight(name='fp', initializer='zeros')
        self.false_negatives = self.add_weight(name='fn', initializer='zeros')

    def update_state(self, y_true, y_pred, sample_weight=None):
        y_pred = tf.argmax(y_pred, axis=1)
        y_true = tf.argmax(y_true, axis=1)

        self.true_positives.assign_add(
            tf.cast(tf.math.count_nonzero(y_pred * y_true), tf.float32))
        self.false_positives.assign_add(
            tf.cast(tf.math.count_nonzero(y_pred * (1 - y_true)), tf.float32))
        self.false_negatives.assign_add(
            tf.cast(tf.math.count_nonzero((1 - y_pred) * y_true), tf.float32))

    def result(self):
        precision = self.true_positives / (self.true_positives + self.false_positives + tf.keras.backend.epsilon())
        recall = self.true_positives / (self.true_positives + self.false_negatives + tf.keras.backend.epsilon())
        f1 = 2 * ((precision * recall) / (precision + recall + tf.keras.backend.epsilon()))
        return f1

    def reset_states(self):
        self.true_positives.assign(0.0)
        self.false_positives.assign(0.0)
        self.false_negatives.assign(0.0)


# 强制 TensorFlow 使用第一个可用的 GPU
gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    # 如果你想要限制 TensorFlow 只能使用第一个 GPU
    try:
        # Currently, memory growth needs to be the same across GPUs
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        tf.config.experimental.set_visible_devices(gpus[0], 'GPU')
    except RuntimeError as e:
        # Visible devices must be set at program startup
        print(e)


X, y, unique_word_count = dataProgress.data_progress()
# X: 训练集特征
# y: 训练集标签
max_features = 3000       # 词汇表大小
max_seq_length = 512    # 输入序列的最大长度
num_classes = 4         # 类别数量
y = to_categorical(y, num_classes=num_classes)      # 将标签转换为独热编码形式，以配合损失函数使用
# embedding_dims          # 嵌入层的维度

# DPCNN模型构建
# CNN模型构建（不包含DPCNN的残差连接）
def build_cnn_model(max_features, max_seq_length, num_classes, embedding_dims=256):
    # 输入层
    sequence_input = Input(shape=(max_seq_length,), dtype='int32')

    # 嵌入层
    embedded_sequences = Embedding(max_features, embedding_dims)(sequence_input)

    # 卷积层和全局最大池化层
    x = Conv1D(250, kernel_size=3, padding='same', activation='relu')(embedded_sequences)
    x = GlobalMaxPooling1D()(x)

    # 全连接层
    x = Dense(num_classes, activation='softmax')(x)

    # 构建模型
    model = Model(sequence_input, x)
    return model


# 实例化CNN模型
cnn_model = build_cnn_model(max_features, max_seq_length, num_classes)

# 定义学习率
learning_rate = 0.001

# 创建一个优化器实例，并设置学习率
optimizer = Adam(learning_rate=learning_rate)

# 编译模型，设置损失函数、优化器和评估指标
cnn_model.compile(loss='categorical_crossentropy',
                                   optimizer=optimizer,
                                   metrics=['accuracy', F1Score()])

# 打印模型概述
cnn_model.summary()

# 定义k折交叉验证参数
num_folds = 5
kf = KFold(n_splits=num_folds, shuffle=True)

# 初始化结果列表
# 初始化结果列表
fold_no = 1
loss_per_fold = []
acc_per_fold = []
f1_per_fold = []

# early_stopping = EarlyStopping(monitor='val_accuracy', patience=3, verbose=1)

# K折交叉验证
for train_index, test_index in kf.split(X):
    # 根据索引生成训练数据和测试数据
    X_train_fold, X_test_fold = X[train_index], X[test_index]
    y_train_fold, y_test_fold = y[train_index], y[test_index]

    # 构建CNN模型
    model = build_cnn_model(max_features, max_seq_length, num_classes)  # 使用新的构建模型函数

    # 编译模型
    model.compile(loss='categorical_crossentropy',
                  optimizer=optimizer,
                  metrics=['accuracy', F1Score()])

    # 打印当前折数
    print(f'Training for fold {fold_no} ...')

    # 训练模型
    history = model.fit(X_train_fold, y_train_fold,
                        batch_size=64,
                        epochs=10,
                        verbose=1)
                        #   validation_split=0.1, # 使用10%训练数据作为验证数据
                        #   callbacks=[early_stopping])

    # 在测试集上评估模型
    scores = model.evaluate(X_test_fold, y_test_fold, verbose=0)

    # 记录结果
    loss_per_fold.append(scores[0])
    acc_per_fold.append(scores[1])
    f1_per_fold.append(scores[2])

    # 增加折数
    fold_no += 1

# 打印每折的损失和准确度
for i in range(num_folds):
    print(f'Fold {i + 1} - Loss: {loss_per_fold[i]}, Accuracy: {acc_per_fold[i]}, F1 Score: {f1_per_fold[i]}')

# 打印平均损失和准确度
print('Average scores for all folds:')
print(f'Average Loss: {np.mean(loss_per_fold)}')
print(f'Average Accuracy: {np.mean(acc_per_fold)}')
print(f'Average F1 Score: {np.mean(f1_per_fold)}')