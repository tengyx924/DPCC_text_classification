import os
import jieba
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences


def data_progress():
    # 数据集的根目录
    dataset_root = 'dataset'

    # 存储文本数据及其标签
    texts = []
    labels = []

    # 类别标签映射
    label_map = {
        '法规政策要求': 0,
        '事故案例与安全问题': 1,
        '行业发展与未来趋势': 2,
        '用户体验与需求': 3
    }

    # 初始化Tokenizer
    tokenizer = Tokenizer()

    # 遍历每个类别的文件夹
    for class_dir, label in label_map.items():
        class_dir_path = os.path.join(dataset_root, class_dir)

        # 遍历当前类别文件夹下的所有文件
        for file_name in os.listdir(class_dir_path):
            file_path = os.path.join(class_dir_path, file_name)

            # 确保是文件
            if os.path.isfile(file_path):
                with open(file_path, 'r', encoding='utf-8') as file:
                    text = file.read()
                    # 使用jieba进行中文分词
                    text_cut = " ".join(jieba.cut(text))
                    texts.append(text_cut)
                    labels.append(label)

    # 对文本列表建立词汇索引
    tokenizer.fit_on_texts(texts)

    # 获取词汇表，即tokenizer的词汇索引字典中的所有单词，计算唯一单词的总数
    word_index = tokenizer.word_index
    unique_word_count = len(word_index)
    print(f"Total number of unique words: {unique_word_count}")

    # 将文本转换为整数序列
    sequences = tokenizer.texts_to_sequences(texts)

    # 设置序列的最大长度
    max_seq_length = 512

    # 填充序列到相同长度，并在必要时从后面截断
    padded_sequences = pad_sequences(sequences, maxlen=max_seq_length, padding='post', truncating='post')

    return padded_sequences, labels, unique_word_count
