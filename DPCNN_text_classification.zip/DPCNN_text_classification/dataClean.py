import os
import re
import jieba
import string


def data_clean():
    dataset_root = 'dataset'

    # 特定词汇列表
    specific_words_to_remove = ['特斯拉', '蔚来', '小鹏', '理想', '华为', '自动驾驶', '辅助驾驶', 'l2', 'L2']

    # 加载中文停用词表
    stopwords_file = 'cn_stopwords.txt'
    with open(stopwords_file, 'r', encoding='utf-8') as f:
        stopwords = [line.strip() for line in f.readlines()]

    # 合并中英文标点符号集合
    punctuation = string.punctuation

    # 遍历数据集的每个子文件夹
    for class_dir in os.listdir(dataset_root):
        # 获取子文件夹的完整路径
        class_dir_path = os.path.join(dataset_root, class_dir)

        # 确保当前路径是文件夹cihuibiao
        if os.path.isdir(class_dir_path):
            # 遍历该子文件夹下的所有文件
            for file_name in os.listdir(class_dir_path):
                # 获取文件的完整路径
                file_path = os.path.join(class_dir_path, file_name)

                # 确保当前路径是文件
                if os.path.isfile(file_path):
                    # 打开文件进行读取和清洗
                    with open(file_path, 'r', encoding='utf-8') as file:
                        text = file.read()

                        # 使用正则表达式删除所有空白字符
                        text = re.sub(r'\s+', ' ', text)

                        # 使用jieba进行中文分词
                        words = jieba.cut(text, cut_all=False)

                        # 删除特定词汇和停用词，并去除标点符号
                        words = [word for word in words if word not in specific_words_to_remove and word not in stopwords and not all(ch in punctuation for ch in word)]

                        # 重组为处理过的文本
                        text = ' '.join(words)

                    # 写回清洗后的文本到文件
                    with open(file_path, 'w', encoding='utf-8') as file:
                        file.write(text)
